import time
from machine import Pin
time.sleep(0.1) # Wait for USB to become ready

counter = 0

btn1 = Pin(3, Pin.IN, Pin.PULL_DOWN)
led_pins = [21, 20, 19, 18]
leds = [Pin(i, Pin.OUT) for i in led_pins]


while True:
    if btn1.value():
        counter += 1
        if counter >= 16:
            counter = 0
        binary_value = bin(counter)[2:]
        binary_value = "0"*(4-len(binary_value)) + binary_value
        for i, state in enumerate(binary_value):
            print(binary_value)
            s = int(state)
            leds[i].value(s)
        time.sleep(0.5)

print("Hello, Pi Pico!")
